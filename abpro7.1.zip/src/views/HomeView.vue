<template>
<div>
  <NavBar />
  <Cursos />
</div>
</template>

<script>
import NavBar from  '@/components/NavBar.vue'
import Cursos from '@/components/Cursos.vue'
export default {
  components:{
    NavBar,
    Cursos
  }
}
</script>

<style>

</style>